"""
# @Author           : Albert Wang
# @Copyright Notice : Copyright (c) 2022 Albert Wang 王子睿, All Rights Reserved.
# @Time             : 2022-02-01 22:20:16
# @Description      :
# @Email            : shadowofgost@outlook.com
# @FilePath         : /WebBackend/src/Services/ModelLocation.py
# @LastAuthor       : Albert Wang
# @LastTime         : 2022-02-01 22:20:18
# @Software         : Vscode
"""
