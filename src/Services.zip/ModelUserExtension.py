"""
# @Author           : Albert Wang
# @Copyright Notice : Copyright (c) 2022 Albert Wang 王子睿, All Rights Reserved.
# @Time             : 2022-02-01 22:29:03
# @Description      :
# @Email            : shadowofgost@outlook.com
# @FilePath         : /WebBackend/src/Services/ModelUserExtension.py
# @LastAuthor       : Albert Wang
# @LastTime         : 2022-02-01 22:29:05
# @Software         : Vscode
"""
