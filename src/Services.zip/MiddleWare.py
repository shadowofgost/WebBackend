"""
# @Author           : Albert Wang
# @Copyright Notice : Copyright (c) 2022 Albert Wang 王子睿, All Rights Reserved.
# @Time             : 2022-01-27 18:23:00
# @Description      :
# @Email            : shadowofgost@outlook.com
# @FilePath         : /WebBackend/src/Services/MiddleWare.py
# @LastAuthor       : Albert Wang
# @LastTime         : 2022-01-27 18:23:01
# @Software         : Vscode
"""
