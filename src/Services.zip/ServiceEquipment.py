"""
# @Author           : Albert Wang
# @Copyright Notice : Copyright (c) 2022 Albert Wang 王子睿, All Rights Reserved.
# @Time             : 2022-02-01 22:19:57
# @Description      :
# @Email            : shadowofgost@outlook.com
# @FilePath         : /WebBackend/src/Services/ModelEquipment.py
# @LastAuthor       : Albert Wang
# @LastTime         : 2022-02-01 22:19:59
# @Software         : Vscode
"""
