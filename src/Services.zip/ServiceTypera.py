"""
# @Author           : Albert Wang
# @Copyright Notice : Copyright (c) 2022 Albert Wang 王子睿, All Rights Reserved.
# @Time             : 2022-02-01 22:21:49
# @Description      :
# @Email            : shadowofgost@outlook.com
# @FilePath         : /WebBackend/src/Services/ModelTypera.py
# @LastAuthor       : Albert Wang
# @LastTime         : 2022-02-01 22:21:51
# @Software         : Vscode
"""
