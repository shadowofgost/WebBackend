"""
# @Author           : Albert Wang
# @Copyright Notice : Copyright (c) 2022 Albert Wang 王子睿, All Rights Reserved.
# @Time             : 2022-02-01 22:19:24
# @Description      :
# @Email            : shadowofgost@outlook.com
# @FilePath         : /WebBackend/src/Services/ServiceCoursePlan.py
# @LastAuthor       : Albert Wang
# @LastTime         : 2022-02-02 17:40:52
# @Software         : Vscode
"""
