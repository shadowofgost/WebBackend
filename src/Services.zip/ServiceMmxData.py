"""
# @Author           : Albert Wang
# @Copyright Notice : Copyright (c) 2022 Albert Wang 王子睿, All Rights Reserved.
# @Time             : 2022-02-01 22:21:08
# @Description      :
# @Email            : shadowofgost@outlook.com
# @FilePath         : /WebBackend/src/Services/ModelMmxData.py
# @LastAuthor       : Albert Wang
# @LastTime         : 2022-02-01 22:21:10
# @Software         : Vscode
"""
