"""
# @Author           : Albert Wang
# @Copyright Notice : Copyright (c) 2022 Albert Wang 王子睿, All Rights Reserved.
# @Time             : 2022-02-01 22:21:37
# @Description      :
# @Email            : shadowofgost@outlook.com
# @FilePath         : /WebBackend/src/Services/ModelTableInformation.py
# @LastAuthor       : Albert Wang
# @LastTime         : 2022-02-01 22:21:39
# @Software         : Vscode
"""
